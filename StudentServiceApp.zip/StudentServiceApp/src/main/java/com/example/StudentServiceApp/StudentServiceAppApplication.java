package com.example.StudentServiceApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentServiceAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentServiceAppApplication.class, args);
	}

}
